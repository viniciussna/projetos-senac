import { useState } from 'react';
import {
  View, Text, TouchableOpacity, Image, StyleSheet,
  ScrollView, ActivityIndicator, Alert, SafeAreaView, StatusBar,
} from 'react-native';

const TIPO_CORES = {
  fire:'#f08030', water:'#6890f0', grass:'#78c850',
  electric:'#f8d030', psychic:'#f85888', ice:'#98d8d8',
  dragon:'#7038f8', dark:'#705848', fairy:'#ee99ac',
  normal:'#a8a878', fighting:'#c03028', flying:'#a890f0',
  poison:'#a040a0', ground:'#e0c068', rock:'#b8a038',
  bug:'#a8b820', ghost:'#705898', steel:'#b8b8d0',
};

export default function App() {
  const [pokemon, setPokemon] = useState(null);
  const [loading, setLoading] = useState(false);

  async function sortear() {
    setLoading(true);
    setPokemon(null);

    try {
      const id = Math.floor(Math.random() * 898) + 1;
      const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
      const d = await res.json();
      const stat = (nome) => d.stats.find(s => s.stat.name === nome)?.base_stat || 0;

      setPokemon({
        pokeId: d.id,
        name: d.name,
        types: d.types.map(t => t.type.name),
        img: d.sprites.other?.['official-artwork']?.front_default || d.sprites.front_default,
        hp: stat('hp'),
        attack: stat('attack'),
        defense: stat('defense'),
        speed: stat('speed'),
        weight: (d.weight / 10).toFixed(1),
        height: (d.height / 10).toFixed(1),
      });
    } catch {
      Alert.alert('Erro', 'Não foi possível sortear. Verifique sua conexão.');
    } finally {
      setLoading(false);
    }
  }

  const corTipo = pokemon ? (TIPO_CORES[pokemon.types[0]] || '#888') : '#333';

  return (
    <SafeAreaView style={s.tela}>
      <StatusBar barStyle="light-content" />

      <Text style={s.titulo}>Card<Text style={s.amarelo}>Pokémon</Text></Text>

      <ScrollView contentContainerStyle={s.scroll}>

        {/* Card */}
        <View style={[s.card, { borderColor: corTipo }]}>
          {loading && (
            <ActivityIndicator size="large" color="#cc0000" style={{ padding: 60 }} />
          )}

          {!loading && !pokemon && (
            <Text style={s.vazio}>Toque no botão abaixo{'\n'}para revelar um Pokémon!</Text>
          )}

          {!loading && pokemon && (
            <>
              <Text style={s.pokeNome}>{pokemon.name}</Text>
              <Text style={s.pokeId}>#{String(pokemon.pokeId).padStart(3, '0')}</Text>

              <Image source={{ uri: pokemon.img }} style={s.pokeImg} resizeMode="contain" />

              <View style={s.tipos}>
                {pokemon.types.map(t => (
                  <View key={t} style={[s.tipoBadge, { backgroundColor: TIPO_CORES[t] || '#888' }]}>
                    <Text style={s.tipoBadgeTexto}>{t}</Text>
                  </View>
                ))}
              </View>

              <Text style={s.pokeInfo}>Peso: {pokemon.weight}kg  |  Altura: {pokemon.height}m</Text>

              {[
                { label: 'HP',  val: pokemon.hp },
                { label: 'ATK', val: pokemon.attack },
                { label: 'DEF', val: pokemon.defense },
                { label: 'VEL', val: pokemon.speed },
              ].map(({ label, val }) => (
                <View key={label} style={s.statRow}>
                  <Text style={s.statLabel}>{label}</Text>
                  <View style={s.statFundo}>
                    <View style={[s.statBarra, { width: `${(val / 255) * 100}%`, backgroundColor: corTipo }]} />
                  </View>
                  <Text style={s.statValor}>{val}</Text>
                </View>
              ))}
            </>
          )}
        </View>

        {/* Botão */}
        <TouchableOpacity
          style={[s.btn, loading && { opacity: 0.5 }]}
          onPress={sortear}
          disabled={loading}
        >
          <Text style={s.btnTexto}>✦ Sortear Pokémon ✦</Text>
        </TouchableOpacity>

      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  tela:   { flex: 1, backgroundColor: '#0f0f0f' },
  titulo: { color: '#fff', fontSize: 22, fontWeight: '900', textAlign: 'center', paddingTop: 20, paddingBottom: 10 },
  amarelo:{ color: '#ffcb05' },
  scroll: { padding: 16, gap: 16, alignItems: 'center' },

  card:       { width: '100%', borderWidth: 2, borderRadius: 20, backgroundColor: '#1a1a1a', padding: 20, alignItems: 'center', gap: 8 },
  vazio:      { color: '#555', fontSize: 14, textAlign: 'center', paddingVertical: 60, lineHeight: 24 },
  pokeNome:   { color: '#fff', fontSize: 22, fontWeight: '900', textTransform: 'capitalize' },
  pokeId:     { color: '#555', fontSize: 13 },
  pokeImg:    { width: 180, height: 180 },
  pokeInfo:   { color: '#666', fontSize: 12 },

  tipos:          { flexDirection: 'row', gap: 6 },
  tipoBadge:      { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 99 },
  tipoBadgeTexto: { color: '#fff', fontSize: 11, fontWeight: '800', textTransform: 'uppercase' },

  statRow:   { flexDirection: 'row', alignItems: 'center', gap: 8, width: '100%' },
  statLabel: { color: '#aaa', fontSize: 10, fontWeight: '800', width: 32 },
  statFundo: { flex: 1, height: 6, backgroundColor: '#333', borderRadius: 99, overflow: 'hidden' },
  statBarra: { height: '100%', borderRadius: 99 },
  statValor: { color: '#fff', fontSize: 11, fontWeight: '800', width: 28, textAlign: 'right' },

  btn:     { backgroundColor: '#cc0000', padding: 16, borderRadius: 12, alignItems: 'center', width: '100%' },
  btnTexto:{ color: '#fff', fontWeight: '800', fontSize: 15 },
});