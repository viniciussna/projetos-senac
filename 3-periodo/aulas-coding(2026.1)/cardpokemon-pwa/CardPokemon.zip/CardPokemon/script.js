/* ============================
   CardPokemon – script.js
============================ */

// ── Splash Screen ──────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    const splash = document.getElementById('splash');
    splash.classList.add('hidden');
  }, 1400);
});

// ── Service Worker ─────────────────────────────
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.warn('SW falhou:', err));
  });
}

// ── Elements ───────────────────────────────────
const btn       = document.getElementById('btnDraw');
const card      = document.getElementById('pokemon-card');
const statsBar  = document.getElementById('stats-bar');

// ── Type colors (for card bg gradient) ─────────
const typeColors = {
  fire:'#f08030', water:'#6890f0', grass:'#78c850',
  electric:'#f8d030', psychic:'#f85888', ice:'#98d8d8',
  dragon:'#7038f8', dark:'#705848', fairy:'#ee99ac',
  normal:'#a8a878', fighting:'#c03028', flying:'#a890f0',
  poison:'#a040a0', ground:'#e0c068', rock:'#b8a038',
  bug:'#a8b820', ghost:'#705898', steel:'#b8b8d0'
};

// ── Fetch Pokémon ───────────────────────────────
async function getPokemon() {
  btn.disabled = true;

  // loading shimmer
  card.className = 'card loading';
  card.innerHTML = '<div class="card-inner"></div>';
  statsBar.classList.add('hidden');

  try {
    const id       = Math.floor(Math.random() * 898) + 1;
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
    if (!response.ok) throw new Error('API error');
    const data = await response.json();

    renderCard(data);
    renderStats(data);
    vibrar([50, 30, 80]); // hardware: vibração

  } catch (err) {
    console.error(err);
    card.className = 'card card-empty';
    card.innerHTML = `
      <div class="card-inner">
        <div class="empty-state">
          <p>Erro ao carregar.<br>Tente novamente!</p>
        </div>
      </div>`;
  } finally {
    btn.disabled = false;
  }
}

// ── Render Card ─────────────────────────────────
function renderCard(data) {
  const name   = data.name;
  const id     = String(data.id).padStart(3, '0');
  const img    = data.sprites.other['official-artwork']?.front_default
               || data.sprites.front_default;
  const types  = data.types.map(t => t.type.name);
  const type1  = types[0];
  const color1 = typeColors[type1] || '#888';
  const color2 = types[1] ? (typeColors[types[1]] || '#555') : color1;

  const peso   = (data.weight / 10).toFixed(1) + ' kg';
  const altura = (data.height / 10).toFixed(1) + ' m';

  card.className = 'card';
  card.innerHTML = `
    <div class="card-inner" style="background: linear-gradient(160deg, #1a1a1a 0%, #0d0d0d 100%);">
      <div class="card-lines"></div>
      <div class="card-content">
        <div class="card-header">
          <span class="pokemon-name">${name}</span>
          <span class="pokemon-id">#${id}</span>
        </div>
        <div class="card-image-area">
          <div class="card-bg-circle" style="background: ${color1};"></div>
          <img class="pokemon-img" src="${img}" alt="${name}" loading="lazy">
        </div>
        <div class="card-footer">
          <div class="card-detail">
            <span class="card-detail-label">Tipo</span>
            <div style="display:flex;gap:4px;margin-top:2px;">
              ${types.map(t => `<span class="type-badge type-${t}">${t}</span>`).join('')}
            </div>
          </div>
          <div class="card-detail">
            <span class="card-detail-label">Peso</span>
            <span class="card-detail-value">${peso}</span>
          </div>
          <div class="card-detail">
            <span class="card-detail-label">Altura</span>
            <span class="card-detail-value">${altura}</span>
          </div>
        </div>
      </div>
      <div class="card-holo"></div>
    </div>`;

  // flip animation
  requestAnimationFrame(() => {
    card.classList.add('flip');
    setTimeout(() => card.classList.remove('flip'), 700);
  });
}

// ── Render Stats ────────────────────────────────
function renderStats(data) {
  const stats = data.stats;
  const hp  = stats.find(s => s.stat.name === 'hp')?.base_stat  || 0;
  const atk = stats.find(s => s.stat.name === 'attack')?.base_stat || 0;
  const def = stats.find(s => s.stat.name === 'defense')?.base_stat || 0;
  const spd = stats.find(s => s.stat.name === 'speed')?.base_stat || 0;
  const max = 255;

  const set = (id, fillId, val) => {
    document.getElementById(id).textContent = val;
    setTimeout(() => {
      document.getElementById(fillId).style.width = `${(val/max)*100}%`;
    }, 100);
  };

  statsBar.classList.remove('hidden');
  // reset fills instantly
  ['fill-hp','fill-atk','fill-def','fill-spd'].forEach(id => {
    document.getElementById(id).style.width = '0%';
  });

  set('val-hp',  'fill-hp',  hp);
  set('val-atk', 'fill-atk', atk);
  set('val-def', 'fill-def', def);
  set('val-spd', 'fill-spd', spd);
}

// ── Hardware: Vibração ──────────────────────────
function vibrar(pattern) {
  if ('vibrate' in navigator) {
    navigator.vibrate(pattern);
  }
}

// ── Hardware: Shake to draw ─────────────────────
let lastX, lastY, lastZ;
let lastShake = 0;

function handleMotion(event) {
  const acc = event.accelerationIncludingGravity;
  if (!acc) return;

  const { x, y, z } = acc;
  if (lastX === undefined) { lastX = x; lastY = y; lastZ = z; return; }

  const delta = Math.abs(x - lastX) + Math.abs(y - lastY) + Math.abs(z - lastZ);
  lastX = x; lastY = y; lastZ = z;

  const now = Date.now();
  if (delta > 25 && now - lastShake > 1500) {
    lastShake = now;
    if (!btn.disabled) getPokemon();
  }
}

if ('DeviceMotionEvent' in window) {
  if (typeof DeviceMotionEvent.requestPermission === 'function') {
    // iOS 13+ requires permission
    btn.addEventListener('click', async () => {
      try {
        const perm = await DeviceMotionEvent.requestPermission();
        if (perm === 'granted') {
          window.addEventListener('devicemotion', handleMotion);
          document.getElementById('shake-hint').textContent = '📳 Agite!';
        }
      } catch (e) { /* ignore */ }
    }, { once: true });
  } else {
    window.addEventListener('devicemotion', handleMotion);
  }
} else {
  document.getElementById('shake-hint').style.display = 'none';
}

// ── Main button click ───────────────────────────
btn.addEventListener('click', getPokemon);

// ── PWA Install prompt ──────────────────────────
let deferredPrompt;
const banner = document.createElement('div');
banner.id = 'install-banner';
banner.innerHTML = `
  <div class="install-text">
    Instalar CardPokemon
    <span>Adicione à tela inicial</span>
  </div>
  <button class="install-btn" id="btnInstall">Instalar</button>
  <button class="install-dismiss" id="btnDismiss">✕</button>
`;
document.body.appendChild(banner);

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  setTimeout(() => banner.classList.add('show'), 3000);
});

document.getElementById('btnInstall').addEventListener('click', async () => {
  banner.classList.remove('show');
  if (deferredPrompt) {
    deferredPrompt.prompt();
    const result = await deferredPrompt.userChoice;
    console.log('Install result:', result.outcome);
    deferredPrompt = null;
  }
});

document.getElementById('btnDismiss').addEventListener('click', () => {
  banner.classList.remove('show');
});

window.addEventListener('appinstalled', () => {
  banner.classList.remove('show');
  console.log('PWA instalado!');
});
