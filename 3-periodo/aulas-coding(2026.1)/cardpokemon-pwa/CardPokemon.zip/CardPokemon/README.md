# 🃏 CardPokemon

Aplicação web **PWA** responsiva com foco em **mobile-first**, que consome a **PokéAPI** e exibe cartas animadas de Pokémon com design moderno.

## 🚀 Demo

> Faça deploy no [Netlify](https://netlify.com), [Vercel](https://vercel.com) ou [GitHub Pages](https://pages.github.com) e atualize este link.

## ✨ Funcionalidades

- 🃏 **Carta animada** de Pokémon com flip, float e shimmer holográfico
- 📊 **Stats bar** animada com HP, ATK, DEF e VEL
- 📳 **Agite o celular** para sortear um novo Pokémon (Vibration API + DeviceMotion)
- 📲 **PWA completo** — instale na tela inicial como app nativo
- 🌐 **Funciona offline** graças ao Service Worker com cache inteligente
- 🎨 Design dark com tema Pokémon (vermelho + amarelo)

## 📱 Recursos de Hardware Utilizados

| Recurso | API Web | Uso |
|---------|---------|-----|
| **Vibração** | `navigator.vibrate()` | Feedback ao acertar / errar |
| **Acelerômetro / Giroscópio** | `DeviceMotionEvent` | Agitar = sortear Pokémon |

## 🛠️ Tecnologias

- HTML5 + CSS3 + JavaScript Vanilla
- [PokéAPI](https://pokeapi.co/) — dados dos Pokémon
- Service Worker — cache e funcionamento offline
- Web App Manifest — instalação como PWA

## 📂 Estrutura

```
CardPokemon/
├── index.html         # Estrutura da aplicação
├── style.css          # Design mobile-first
├── script.js          # Lógica, API e hardware
├── service-worker.js  # Cache PWA
├── manifest.json      # Configuração do PWA
├── icon-192.png       # Ícone PWA 192×192
└── icon-512.png       # Ícone PWA 512×512
```

## ▶️ Como executar localmente

```bash
# Clone ou extraia o projeto
cd CardPokemon

# Abra com um servidor local (necessário para Service Worker)
npx serve .
# ou
python -m http.server 8000
```

> ⚠️ Service Workers exigem HTTPS ou `localhost`. Não abra direto pelo `file://`.

## 📦 Como fazer deploy

### Netlify (arraste e solte)
1. Acesse [app.netlify.com](https://app.netlify.com)
2. Arraste a pasta `CardPokemon` para a área de deploy
3. Pronto! ✅

### GitHub Pages
1. Suba os arquivos para um repositório público
2. Vá em **Settings → Pages → Branch: main / root**
3. Aguarde alguns minutos e acesse o link gerado

## 🔍 Lighthouse

Para verificar as métricas:
1. Abra o app no Chrome
2. DevTools → **Lighthouse**
3. Mobile → Analyze

Pontos avaliados: Performance, Acessibilidade, Boas práticas, SEO e PWA.
