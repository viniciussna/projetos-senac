async function getPokemon(){

    try{

        // gera número aleatório
        let id = Math.floor(Math.random() * 151) + 1;

        // busca dados na API
        let response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);

        // converte para JSON
        let data = await response.json();

        // pega informações do pokemon
        let nome = data.name;
        let imagem = data.sprites.front_default;
        let tipo = data.types[0].type.name;
        let peso = data.weight;
        let altura = data.height;

        // mostra na tela
        document.getElementById("pokemon").innerHTML = `
            <h2>${nome}</h2>
            <img src="${imagem}">
            <p><strong>Tipo:</strong> ${tipo}</p>
            <p><strong>Peso:</strong> ${peso}</p>
            <p><strong>Altura:</strong> ${altura}</p>
        `

    }

    catch(erro){

        console.error(erro);

        document.getElementById("pokemon").innerHTML = `
        <p>Erro ao carregar Pokémon.</p>
        <p>Verifique a conexão com a internet.</p>
        `

    }

}